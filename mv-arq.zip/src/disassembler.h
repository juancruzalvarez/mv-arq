#ifndef DISASSEMBLER_H_
#define DISASSEMBLER_H_

#include "mv.h"
#include "instruccion.h"

void MostrarInstruccion(MV mv, Instruccion instruccion);

#endif